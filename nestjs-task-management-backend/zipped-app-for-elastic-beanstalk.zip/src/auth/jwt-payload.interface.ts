export interface JwtPayload {
  username: string;
}
